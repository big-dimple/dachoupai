import {runSteps} from '/workspace/dachoupai/scripts/check-runner.mjs';
import {writeFileSync} from 'node:fs';
const report=runSteps('/workspace/dachoupai',[
{name:'directed-current-decisions',command:'npx',args:['vitest','run','tests/shop-current-decisions.test.ts','tests/shop-route-relations.test.ts','tests/build-journey.test.ts','tests/build-journey-dialog.test.ts','tests/hand-route-guidance.test.ts','tests/first-chapter-guide.test.ts']},
{name:'typecheck',command:'npm',args:['run','typecheck']},
{name:'limited-current-ui',command:'node',args:['/tmp/w6-current-decision-ui.mjs']}
]);writeFileSync('/tmp/w6-current-decisions-gate.json',JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report));process.exitCode=report.exitCode;
