import {runSteps} from '/workspace/dachoupai/scripts/check-runner.mjs';import {writeFileSync} from 'node:fs';
const report=runSteps('/workspace/dachoupai',[
{name:'review-directed',command:'npx',args:['vitest','run','tests/shop-current-decisions.test.ts','tests/shop-route-relations.test.ts','tests/build-journey.test.ts','tests/build-journey-dialog.test.ts']},
{name:'typecheck',command:'npm',args:['run','typecheck']},
{name:'two-review-ui-examples',command:'node',args:['/tmp/w6-pr55-review-ui.mjs']}]);
writeFileSync('/tmp/w6-pr55-review-gate.json',JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report));process.exitCode=report.exitCode;
